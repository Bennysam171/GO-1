#!/usr/bin/env bash
# ============================================================
# TipFusion AI Ultimate — VPS Deployment Script
# Tested on Ubuntu 22.04 LTS
# ============================================================
# Usage:
#   chmod +x deploy/setup_vps.sh
#   sudo ./deploy/setup_vps.sh
# ============================================================

set -euo pipefail

echo "============================================"
echo "  TipFusion AI — VPS Setup"
echo "============================================"

# ── 1. System Update ────────────────────────────────────────
echo "[1/10] Updating system..."
apt-get update && apt-get upgrade -y

# ── 2. Install dependencies ─────────────────────────────────
echo "[2/10] Installing system packages..."
apt-get install -y \
    python3.11 python3.11-venv python3.11-dev \
    python3-pip \
    tesseract-ocr tesseract-ocr-eng \
    android-tools-adb \
    libglib2.0-0 libsm6 libxext6 libxrender-dev libgomp1 \
    libgl1-mesa-glx \
    nginx certbot python3-certbot-nginx \
    postgresql postgresql-contrib \
    redis-server \
    git curl wget unzip \
    supervisor \
    docker.io docker-compose-plugin

# ── 3. Configure PostgreSQL ──────────────────────────────────
echo "[3/10] Configuring PostgreSQL..."
systemctl start postgresql
systemctl enable postgresql

sudo -u postgres psql -c "CREATE USER tipfusion WITH PASSWORD 'tipfusion_secure_pass';" 2>/dev/null || true
sudo -u postgres psql -c "CREATE DATABASE tipfusion OWNER tipfusion;" 2>/dev/null || true
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE tipfusion TO tipfusion;" 2>/dev/null || true

# ── 4. Configure Redis ───────────────────────────────────────
echo "[4/10] Configuring Redis..."
systemctl start redis-server
systemctl enable redis-server

# ── 5. Clone / copy app ──────────────────────────────────────
echo "[5/10] Setting up application..."
APP_DIR="/opt/tipfusion"
mkdir -p "$APP_DIR"

# If running from git:
# git clone https://github.com/your-repo/tipfusion.git "$APP_DIR"
# For local deploy, copy files:
cp -r . "$APP_DIR/" 2>/dev/null || echo "  (Files already in place)"

cd "$APP_DIR"

# ── 6. Python virtualenv ─────────────────────────────────────
echo "[6/10] Creating virtual environment..."
python3.11 -m venv venv
source venv/bin/activate
pip install --upgrade pip
pip install -r requirements.txt
playwright install chromium
playwright install-deps chromium

# ── 7. Environment file ──────────────────────────────────────
echo "[7/10] Setting up environment..."
if [ ! -f .env ]; then
    cp .env.example .env
    echo "  ⚠️  IMPORTANT: Edit /opt/tipfusion/.env with your API keys!"
fi

# ── 8. Initialize DB ─────────────────────────────────────────
echo "[8/10] Initializing database..."
source venv/bin/activate
python main.py initdb

# ── 9. Supervisor (process manager) ─────────────────────────
echo "[9/10] Configuring Supervisor..."
cat > /etc/supervisor/conf.d/tipfusion.conf << 'SUPERVISOR_CONF'
[program:tipfusion]
command=/opt/tipfusion/venv/bin/python /opt/tipfusion/main.py serve --host 127.0.0.1 --port 8000
directory=/opt/tipfusion
user=www-data
autostart=true
autorestart=true
redirect_stderr=true
stdout_logfile=/opt/tipfusion/logs/supervisor.log
stdout_logfile_maxbytes=10MB
stdout_logfile_backups=5
environment=PYTHONPATH="/opt/tipfusion"
SUPERVISOR_CONF

chown -R www-data:www-data "$APP_DIR/logs"
supervisorctl reread
supervisorctl update
supervisorctl start tipfusion

# ── 10. Nginx reverse proxy ──────────────────────────────────
echo "[10/10] Configuring Nginx..."
cat > /etc/nginx/sites-available/tipfusion << 'NGINX_CONF'
server {
    listen 80;
    server_name _;  # Replace with your domain

    location / {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
        proxy_read_timeout 300s;
        proxy_connect_timeout 10s;
    }

    # WebSocket support (if needed)
    location /ws {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
}
NGINX_CONF

ln -sf /etc/nginx/sites-available/tipfusion /etc/nginx/sites-enabled/
rm -f /etc/nginx/sites-enabled/default
nginx -t && systemctl reload nginx

echo ""
echo "============================================"
echo "  ✅ TipFusion AI Deployed Successfully!"
echo "============================================"
echo ""
echo "  🌐 API:          http://YOUR_SERVER_IP"
echo "  📚 Docs:         http://YOUR_SERVER_IP/docs"
echo "  📊 Status:       supervisorctl status tipfusion"
echo "  📋 Logs:         tail -f /opt/tipfusion/logs/supervisor.log"
echo ""
echo "  ⚠️  Next Steps:"
echo "  1. Edit /opt/tipfusion/.env with your API keys"
echo "  2. supervisorctl restart tipfusion"
echo "  3. (Optional) certbot --nginx -d yourdomain.com"
echo ""
