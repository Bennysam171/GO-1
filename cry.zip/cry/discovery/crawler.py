"""
TipFusion AI — Auto Source Discovery Engine
Continuously scans the web for new football prediction sources:
- Telegram channels
- Twitter accounts
- Reddit communities
- Prediction websites
- Android apps
"""

import re
import asyncio
from typing import List, Dict, Optional, Set
from dataclasses import dataclass
from urllib.parse import urlparse

import aiohttp
from bs4 import BeautifulSoup

from core.config import settings
from core.logger import logger
from database.models import SourceType
from database.connection import AsyncSessionLocal
from database import crud

# ============================================================
# SEED QUERIES
# ============================================================

WEB_SEARCH_QUERIES = [
    "football predictions telegram channel",
    "free football tips telegram 2024",
    "betting predictions website free",
    "soccer prediction site",
    "football tipster twitter",
    "soccer betting reddit community",
    "AI football predictions free",
    "daily football tips free",
    "sure football predictions today",
    "Nigeria football predictions",
    "Premier League predictions free",
]

# Patterns to identify Telegram channels in text
TELEGRAM_CHANNEL_PATTERNS = [
    re.compile(r"(?:t\.me|telegram\.me)/([a-zA-Z0-9_]{5,32})", re.IGNORECASE),
    re.compile(r"@([a-zA-Z0-9_]{5,32})\s+(?:channel|group|tips|predictions)", re.IGNORECASE),
]

# Patterns for Twitter accounts
TWITTER_ACCOUNT_PATTERNS = [
    re.compile(r"(?:twitter\.com|x\.com)/([a-zA-Z0-9_]{4,15})", re.IGNORECASE),
    re.compile(r"@([a-zA-Z0-9_]{4,15})(?:\s+on twitter|\s+twitter)", re.IGNORECASE),
]

# Patterns for Reddit communities
REDDIT_PATTERNS = [
    re.compile(r"reddit\.com/r/([a-zA-Z0-9_]+)", re.IGNORECASE),
    re.compile(r"r/([a-zA-Z0-9_]+)\s+(?:reddit|community|sub)", re.IGNORECASE),
]

# Patterns for prediction website URLs
WEBSITE_PATTERNS = [
    re.compile(r"https?://(?:www\.)?([a-z0-9-]+\.[a-z]{2,})/(?:prediction|tips|forecast)", re.IGNORECASE),
]

# Blacklisted domains (gambling sites, spam, etc.)
BLACKLISTED_DOMAINS = {
    "bet365.com", "williamhill.com", "betway.com", "1xbet.com",
    "spam.com", "facebook.com", "instagram.com", "youtube.com",
}

# Keywords that indicate a source is football-related
FOOTBALL_KEYWORDS = {
    "football", "soccer", "betting", "prediction", "tips", "tipster",
    "odds", "goals", "match", "premier", "league", "champions", "fixture",
    "1x2", "over 2.5", "btts", "accumulator", "acca", "banker",
}


@dataclass
class DiscoveredSource:
    type: str
    identifier: str
    name: str
    description: Optional[str] = None
    confidence: float = 0.5  # How confident we are this is a good source


class SourceDiscoverer:
    """
    Autonomous source discovery engine.
    Crawls web pages, extracts new sources, and registers them in the DB.
    """

    def __init__(self):
        self._session: Optional[aiohttp.ClientSession] = None
        self._seen_identifiers: Set[str] = set()

    async def _get_session(self) -> aiohttp.ClientSession:
        if self._session is None or self._session.closed:
            self._session = aiohttp.ClientSession(
                headers={"User-Agent": "Mozilla/5.0 (compatible; TipFusionBot/1.0)"},
                timeout=aiohttp.ClientTimeout(total=20),
                connector=aiohttp.TCPConnector(ssl=False),
            )
        return self._session

    def _is_football_related(self, text: str) -> bool:
        """Check if text contains football-betting keywords."""
        text_lower = text.lower()
        matches = sum(1 for kw in FOOTBALL_KEYWORDS if kw in text_lower)
        return matches >= 2

    def _extract_telegram_channels(self, text: str) -> List[str]:
        channels = []
        for pattern in TELEGRAM_CHANNEL_PATTERNS:
            found = pattern.findall(text)
            channels.extend(found)
        return list(set(channels))

    def _extract_twitter_accounts(self, text: str) -> List[str]:
        accounts = []
        for pattern in TWITTER_ACCOUNT_PATTERNS:
            found = pattern.findall(text)
            accounts.extend(found)
        return list(set(accounts))

    def _extract_reddit_subs(self, text: str) -> List[str]:
        subs = []
        for pattern in REDDIT_PATTERNS:
            found = pattern.findall(text)
            subs.extend(found)
        return list(set(subs))

    def _extract_websites(self, text: str, base_url: str = "") -> List[str]:
        """Extract football prediction website URLs."""
        websites = []
        soup = BeautifulSoup(text, "html.parser")

        for a in soup.find_all("a", href=True):
            href = a["href"]
            if not href.startswith("http"):
                continue
            domain = urlparse(href).netloc.replace("www.", "")
            if domain in BLACKLISTED_DOMAINS:
                continue
            anchor_text = a.get_text().lower()
            if self._is_football_related(anchor_text + " " + href):
                websites.append(href)

        return list(set(websites))[:20]

    async def _scrape_page(self, url: str) -> str:
        """Fetch a page and return its text content."""
        try:
            session = await self._get_session()
            async with session.get(url) as resp:
                if resp.status != 200:
                    return ""
                return await resp.text(errors="ignore")
        except Exception as e:
            logger.debug(f"[Discovery] Failed to fetch {url}: {e}")
            return ""

    async def _search_google(self, query: str) -> List[str]:
        """Use a search-engine-like approach to find URLs."""
        # Use DuckDuckGo HTML (no API key required)
        search_url = f"https://html.duckduckgo.com/html/?q={query.replace(' ', '+')}"
        html = await self._scrape_page(search_url)
        if not html:
            return []

        soup = BeautifulSoup(html, "lxml")
        urls = []
        for result in soup.select(".result__url, .result__a"):
            href = result.get("href") or result.get_text()
            if href and href.startswith("http"):
                domain = urlparse(href).netloc.replace("www.", "")
                if domain not in BLACKLISTED_DOMAINS:
                    urls.append(href)

        return urls[:10]

    async def discover_from_page(self, url: str) -> List[DiscoveredSource]:
        """Discover sources from a single web page."""
        html = await self._scrape_page(url)
        if not html or not self._is_football_related(html[:5000]):
            return []

        discovered = []
        text = BeautifulSoup(html, "lxml").get_text()

        # Telegram channels
        for channel in self._extract_telegram_channels(text + html):
            if channel not in self._seen_identifiers:
                self._seen_identifiers.add(channel)
                discovered.append(DiscoveredSource(
                    type="telegram",
                    identifier=channel,
                    name=f"Telegram @{channel}",
                    confidence=0.6,
                ))

        # Twitter accounts
        for account in self._extract_twitter_accounts(text + html):
            if account not in self._seen_identifiers:
                self._seen_identifiers.add(account)
                discovered.append(DiscoveredSource(
                    type="twitter",
                    identifier=account,
                    name=f"Twitter @{account}",
                    confidence=0.5,
                ))

        # Reddit subreddits
        for sub in self._extract_reddit_subs(text + html):
            if sub not in self._seen_identifiers:
                self._seen_identifiers.add(sub)
                discovered.append(DiscoveredSource(
                    type="reddit",
                    identifier=sub,
                    name=f"r/{sub}",
                    confidence=0.55,
                ))

        # External websites
        for website_url in self._extract_websites(html, url):
            domain = urlparse(website_url).netloc.replace("www.", "")
            if domain not in self._seen_identifiers and domain not in BLACKLISTED_DOMAINS:
                self._seen_identifiers.add(domain)
                discovered.append(DiscoveredSource(
                    type="web",
                    identifier=website_url,
                    name=domain,
                    confidence=0.45,
                ))

        return discovered

    async def run_discovery(self) -> List[DiscoveredSource]:
        """Full discovery cycle."""
        all_discovered = []
        logger.info("🔭 [Discovery] Starting source discovery cycle...")

        for query in WEB_SEARCH_QUERIES:
            logger.debug(f"[Discovery] Query: {query}")
            urls = await self._search_google(query)

            for url in urls:
                sources = await self.discover_from_page(url)
                all_discovered.extend(sources)
                await asyncio.sleep(1.5)  # Rate limiting

        logger.info(f"[Discovery] Found {len(all_discovered)} potential new sources")
        return all_discovered

    async def save_discovered_sources(self, sources: List[DiscoveredSource]):
        """Save newly discovered sources to database."""
        type_map = {
            "telegram": SourceType.TELEGRAM,
            "twitter": SourceType.TWITTER,
            "reddit": SourceType.REDDIT,
            "web": SourceType.WEB,
        }

        new_count = 0
        async with AsyncSessionLocal() as db:
            for src in sources:
                source_type = type_map.get(src.type)
                if not source_type:
                    continue

                _, created = await crud.get_or_create_source(
                    db,
                    name=src.name,
                    source_type=source_type,
                    identifier=src.identifier,
                    auto_discovered=True,
                    is_active=True,
                )
                if created:
                    new_count += 1

            await db.commit()

        logger.success(f"✅ [Discovery] Registered {new_count} new sources")

    async def run(self):
        """Full discovery + save cycle."""
        discovered = await self.run_discovery()
        await self.save_discovered_sources(discovered)

        if self._session:
            await self._session.close()
