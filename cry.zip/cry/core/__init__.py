"""TipFusion AI — Core Package"""
